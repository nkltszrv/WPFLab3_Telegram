using System.Windows;
using System.Windows.Controls;

namespace WPFLab3_Telegram.views;

public partial class SettingsView : UserControl
{
    public SettingsView()
    {
        InitializeComponent();
    }
    private void LightTheme_Click(object sender, RoutedEventArgs e)
    {
        (Application.Current as App)?.ChangeTheme(false);
    }
    private void DarkTheme_Click(object sender, RoutedEventArgs e)
    {
        (Application.Current as App)?.ChangeTheme(true);
    }
}