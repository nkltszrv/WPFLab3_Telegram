using System.Windows;
using System.Windows.Controls;

namespace WPFLab3_Telegram.views;

public partial class ChannelConnectView : UserControl
{
    public ChannelConnectView()
    {
        InitializeComponent();
    }
    private void Connect_Click(object sender, RoutedEventArgs e)
    {
        App.ApiKey = ApiKey.Text;
        App.ChannelId = ChannelId.Text;
    }
}