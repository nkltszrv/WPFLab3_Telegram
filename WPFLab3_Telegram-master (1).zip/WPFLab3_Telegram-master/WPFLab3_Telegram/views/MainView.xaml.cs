using System.Windows;
using System.Windows.Controls;

namespace WPFLab3_Telegram.views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
        MainContent.Content = new ChannelConnectView();
    }
    
    private void ChangeView(object sender, RoutedEventArgs e)
    {
        var button = sender as Button;
        switch (button.Name)
        {
            case "btnConnect":
                MainContent.Content = new ChannelConnectView();
                break;
            case "btnPublish":
                MainContent.Content = new MessagePubView();
                break;
            case "btnSettings":
                MainContent.Content = new SettingsView();
                break;
        }
    }
}