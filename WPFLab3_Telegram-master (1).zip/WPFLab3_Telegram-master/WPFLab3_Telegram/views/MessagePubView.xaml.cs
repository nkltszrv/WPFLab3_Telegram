using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;

namespace WPFLab3_Telegram.views;

public partial class MessagePubView : UserControl
{
    private string selectedImagePath;
    public MessagePubView()
    {
        InitializeComponent();
    }
    
    private void UploadImage_Click(object sender, RoutedEventArgs e)
    {
        OpenFileDialog openFileDialog = new OpenFileDialog
        {
            Filter = "Image files (*.png;*.jpeg;*.jpg)|*.png;*.jpeg;*.jpg",
            InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures)
        };

        if (openFileDialog.ShowDialog() == true)
        {
            selectedImagePath = openFileDialog.FileName;
        }
    }
    
    private async void Send_Message(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(selectedImagePath))
            {
                MessageBox.Show("Пожалуйста, выберите изображение для отправки.");
                return;
            }

            await SendMessageAsync(App.ChannelId, selectedImagePath, MessageText.Text);
        }

    public async Task SendMessageAsync(string chatId, string imagePath, string caption)
    {
        using (var client = new HttpClient())
        {
            var requestContent = new MultipartFormDataContent();
            requestContent.Add(new StringContent(chatId), "chat_id");
            requestContent.Add(new StringContent(caption), "caption");
            
            var imageContent = new ByteArrayContent(File.ReadAllBytes(imagePath));
            imageContent.Headers.ContentType = MediaTypeHeaderValue.Parse("image/jpeg");
            requestContent.Add(imageContent, "photo", Path.GetFileName(imagePath));
            
            try
            {
                string url = $"https://api.telegram.org/bot{App.ApiKey}/sendPhoto";
                var response = await client.PostAsync(url, requestContent);

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Сообщение успешно отправлено.");
                }
                else
                {
                    MessageBox.Show($"Ошибка при отправке сообщения. Статус: {response.StatusCode}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}");
            }
        }
    }
    
}