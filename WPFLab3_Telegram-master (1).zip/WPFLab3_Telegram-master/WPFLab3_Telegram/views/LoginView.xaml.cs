using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Newtonsoft.Json;

namespace WPFLab3_Telegram.views;



public partial class LoginView : UserControl {
    
    public LoginView()
    {
        InitializeComponent();
    }
    
    private async void Login_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(Username.Text) || string.IsNullOrWhiteSpace(Password.Password))
        {
            MessageBox.Show("Пожалуйста, введите имя пользователя и пароль.");
            return;
        }

        bool loginResult = await TryLoginAsync(Username.Text, Password.Password);
        
        if (loginResult)
        {
            MessageBox.Show("Успешный вход.");
            var mainWnd = Application.Current.MainWindow as MainWindow;
            mainWnd.MainFrame.Navigate(new MainView()); 
        }
        else
        {
            MessageBox.Show("Неверное имя пользователя или пароль.");
        }
    }

    private async Task<bool> TryLoginAsync(string username, string password)
    {
        using (var client = new HttpClient())
        {
            var userData = new { name = username, password = password };
            var json = JsonConvert.SerializeObject(userData);
            var data = new StringContent(json, Encoding.UTF8, "application/json");

            try
            {
                HttpResponseMessage response = await client.PostAsync("http://localhost:5000/users", data);

                if (response.IsSuccessStatusCode)
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при подключении: {ex.Message}");
            }

            return false;
        }
    }
    
    private void Register_Click(object sender, RoutedEventArgs e)
    {
        var mainWnd = Application.Current.MainWindow as MainWindow;
        mainWnd.MainFrame.Navigate(new RegisterView()); 
    }
}