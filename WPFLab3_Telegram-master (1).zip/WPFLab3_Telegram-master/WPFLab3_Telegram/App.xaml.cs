﻿using System;
using System.Configuration;
using System.Data;
using System.Windows;

namespace WPFLab3_Telegram;

/// <summary>
/// Interaction logic for App.xaml
/// </summary>
public partial class App : Application
{
    public static string ApiKey { get; set; }
    public static string ChannelId { get; set; }
    private bool _isDarkTheme = true;
    

    public void ChangeTheme(bool isDarkTheme)
    {
        _isDarkTheme = isDarkTheme;

        // Полный URI для доступа к темам
        var uri = new Uri($"pack://application:,,,/themes/{(_isDarkTheme ? "Dark" : "Light")}.xaml", UriKind.Absolute);
        Current.Resources.MergedDictionaries.Clear();
        Current.Resources.MergedDictionaries.Add(new ResourceDictionary() { Source = uri });
    }
}